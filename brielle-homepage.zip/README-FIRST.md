# Brielle homepage — how to install in GitHub Codespaces on iPad

1. Download `brielle-homepage.zip` on your iPad.
2. In GitHub Codespaces, open the folder that contains your `package.json` file.
3. Upload the ZIP into that folder using the Explorer file menu (or drag it in).
4. Open a NEW terminal in Codespaces. Make sure you are in the project folder
   with `package.json`: `ls package.json`. (If necessary: `cd website`.)
5. Extract over your existing project: `unzip -o brielle-homepage.zip -d .`
6. If the Vite server is running, simply refresh its website preview.
   Otherwise run `npm run dev -- --host 0.0.0.0`.

The ZIP contains only index.html, src/App.jsx, src/App.css,
src/index.css, public/images/, and this README. It will NOT overwrite
package.json, main.jsx, or node_modules.

IMPORTANT: This is a design preview with interactive scent selection.
It cannot accept payments or orders yet. Complete inventory, tax,
shipping, order processing and secure Stripe checkout before launch.

ABOUT THE PHOTO TILES: The four separate mood images for each scent
are cropped out of the Canva collages you uploaded, away from the
central paper label. If you have the full original image files,
replace each cropped image for best resolution.
