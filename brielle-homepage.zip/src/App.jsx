import { useState } from 'react'
import './App.css'

/*
  BRIELLE — HOMEPAGE

  This is a React component. JSX describes the page, while
  App.css controls its appearance. All images live in
  public/images, and /images/... points to those files.

  This is a storefront DESIGN PREVIEW. It does not take payments.
*/

// Each product category has a real Brielle photograph and description.
// The images are editorial photography, not packaging photos.
const collections = [
  {
    title: 'Body Crèmes',
    description: 'Rich, indulgent care for your daily ritual.',
    image: '/images/cream-texture.webp',
    alt: 'Close-up photograph of Brielle body crème texture',
  },
  {
    title: 'Body Lotions',
    description: 'Everyday moisture with a touch of luxury.',
    image: '/images/skin-ritual.webp',
    alt: 'Brielle lotion being tested on skin near green leaves',
  },
  {
    title: 'The Scent Collection',
    description: 'Find the fragrance that feels like you.',
    image: '/images/golden-triptych.webp',
    alt: 'Golden Vanilla moodboard with cream, soft fabric and sugar textures',
  },
]

// This array stores the information for our four fragrance stories.
// Every scent contains FOUR separate photographs for its editorial gallery.
const scents = [
  {
    id: 'golden-vanilla',
    name: 'Golden Vanilla',
    mood: 'Warm · Soft · Comforting',
    description: 'Creamy textures, soft warmth, and a golden kind of comfort.',
    thumbnail: '/images/golden-vanilla-collage.webp',
    gallery: [1, 2, 3, 4].map(n => `/images/golden-vanilla-${n}.webp`),
  },
  {
    id: 'soft-bloom',
    name: 'Soft Bloom',
    mood: 'Floral · Romantic · Delicate',
    description: 'A soft floral mood inspired by petals, dew, and silky fabrics.',
    thumbnail: '/images/soft-bloom-collage.webp',
    gallery: [1, 2, 3, 4].map(n => `/images/soft-bloom-${n}.webp`),
  },
  {
    id: 'midnight-ember',
    name: 'Midnight Ember',
    mood: 'Smoky · Cozy · Moody',
    description: 'An evening atmosphere of warm woods and lingering softness.',
    thumbnail: '/images/midnight-ember-collage.webp',
    gallery: [1, 2, 3, 4].map(n => `/images/midnight-ember-${n}.webp`),
  },
  {
    id: 'lavender-fields',
    name: 'Lavender Fields',
    mood: 'Calming · Golden · Botanical',
    description: 'Lavender at golden hour, gentle linen, and a peaceful ritual.',
    thumbnail: '/images/lavender-fields-collage.webp',
    gallery: [1, 2, 3, 4].map(n => `/images/lavender-fields-${n}.webp`),
  },
]

function App() {
  // React state remembers which scent the visitor selected.
  const [selectedScentId, setSelectedScentId] = useState('golden-vanilla')

  // Find the corresponding scent object in our array.
  const selectedScent = scents.find(scent => scent.id === selectedScentId)

  return (
    <div className="site" id="home">
      {/* Small announcement at the top. */}
      <div className="announcement">SMALL-BATCH BODY CARE · MADE IN BROOKLYN</div>

      {/* Navigation links scroll to sections with matching IDs. */}
      <header className="navbar">
        <a className="brand" href="#home" aria-label="Brielle home">BRIELLE</a>
        <nav aria-label="Main navigation">
          <a href="#collection">Shop</a>
          <a href="#scents">Our Scents</a>
          <a href="#story">Our Story</a>
        </nav>
      </header>

      <main>
        {/* HERO: a split composition inspired by your editorial references. */}
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-copy">
            <p className="eyebrow">THE BRIELLE RITUAL</p>
            <h1 id="hero-title">The art of <em>feeling soft.</em></h1>
            <p className="hero-description">
              Thoughtfully made body care for the moments you take for yourself.
              Born in Brooklyn. Made with love.
            </p>
            <div className="hero-actions">
              <a className="button button-dark" href="#collection">Explore the Collection</a>
              <a className="text-link" href="#scents">Find Your Scent <span aria-hidden="true">↗</span></a>
            </div>
          </div>
          <div className="hero-photo-wrap">
            <img
              className="hero-photo"
              src="/images/hero-skin.webp"
              alt="Glowing, moisturized skin with the words Soft skin. Confident you."
            />
            <span className="photo-note">SKIN FIRST. SOFTNESS ALWAYS.</span>
          </div>
        </section>

        {/* CATEGORY CARDS: actual photos, not fake product packaging. */}
        <section className="section collection" id="collection">
          <div className="section-heading">
            <p className="eyebrow">THE BODY COLLECTION</p>
            <h2>Your ritual begins here.</h2>
            <p>Everyday care, made a little more beautiful.</p>
          </div>
          <div className="collection-grid">
            {collections.map(collection => (
              <article className="collection-card" key={collection.title}>
                <div className="collection-photo">
                  <img src={collection.image} alt={collection.alt} loading="lazy" />
                </div>
                <div className="collection-card-copy">
                  <h3>{collection.title}</h3>
                  <p>{collection.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* SHORT EDITORIAL MOMENT between collection and scent gallery. */}
        <section className="quote-band" aria-label="Brand message">
          <p className="eyebrow">A LITTLE EVERYDAY LUXURY</p>
          <p>Softness is a ritual. <em>Make it yours.</em></p>
        </section>

        {/* SCENT PICKER: onClick updates useState, changing the gallery below. */}
        <section className="section scent-section" id="scents">
          <div className="section-heading">
            <p className="eyebrow">EXPLORE BY FRAGRANCE</p>
            <h2>Find your signature scent.</h2>
            <p>Every fragrance tells a different story. Which one feels like you?</p>
          </div>
          <div className="scent-picker" aria-label="Choose a scent">
            {scents.map(scent => (
              <button
                className={`scent-card ${selectedScentId === scent.id ? 'is-selected' : ''}`}
                type="button"
                key={scent.id}
                onClick={() => setSelectedScentId(scent.id)}
                aria-pressed={selectedScentId === scent.id}
              >
                <img src={scent.thumbnail} alt="" loading="lazy" />
                <span className="scent-card-label">{scent.name}</span>
              </button>
            ))}
          </div>

          {/* ASYMMETRICAL FOUR-IMAGE GALLERY for the currently selected scent. */}
          <div className="scent-feature" aria-live="polite">
            <div className="scent-feature-heading">
              <div>
                <p className="eyebrow">A SCENT STORY</p>
                <h3>{selectedScent.name}</h3>
              </div>
              <div className="scent-feature-description">
                <p className="scent-mood">{selectedScent.mood}</p>
                <p>{selectedScent.description}</p>
              </div>
            </div>
            <div className="mood-grid">
              {selectedScent.gallery.map((image, index) => (
                <img
                  key={image}
                  className={`mood-image mood-image-${index + 1}`}
                  src={image}
                  alt={`${selectedScent.name} mood photograph ${index + 1} of 4`}
                  loading="lazy"
                />
              ))}
            </div>
            <p className="gallery-note">Four separate photographs, arranged like an editorial collage.</p>
          </div>
        </section>

        {/* PROCESS: authentic photographs from Brielle's making process. */}
        <section className="ritual-section" id="ritual">
          <div className="ritual-photo">
            <img src="/images/cream-on-leaf.webp" alt="An open container of Brielle crème on green leaves" loading="lazy" />
          </div>
          <div className="ritual-copy">
            <p className="eyebrow">THE FEELING OF BRIELLE</p>
            <h2>Rich textures. <em>Simple pleasures.</em></h2>
            <p>
              From the first scoop to the last touch, body care should feel like
              a moment worth slowing down for.
            </p>
            <a className="text-link" href="#story">Meet Brielle <span aria-hidden="true">↗</span></a>
          </div>
        </section>

        {/* BRAND STORY: why this small Brooklyn business started. */}
        <section className="story-section" id="story">
          <div className="story-copy">
            <p className="eyebrow">OUR STORY</p>
            <h2>Born from care. <em>Made in Brooklyn.</em></h2>
            <p>
              Brielle began with a simple idea: making a comforting lotion for
              a loved one with sensitive skin. What started as an act of care
              grew into a collection of indulgent body rituals.
            </p>
          </div>
          <div className="story-images">
            <img src="/images/shea-butter.webp" alt="Raw butter used during Brielle's making process" loading="lazy" />
            <img src="/images/cream-texture.webp" alt="Close-up of the finished cream texture" loading="lazy" />
          </div>
        </section>
      </main>

      <footer className="footer">
        <div>
          <p className="footer-brand">BRIELLE</p>
          <p>Brooklyn-born body care.</p>
        </div>
        <div className="footer-links">
          <a href="#collection">Collection</a>
          <a href="#scents">Scents</a>
          <a href="#story">Our Story</a>
        </div>
        <small>© {new Date().getFullYear()} Brielle. All rights reserved.</small>
      </footer>
    </div>
  )
}

// main.jsx imports this component and displays it inside the page's #root.
export default App
